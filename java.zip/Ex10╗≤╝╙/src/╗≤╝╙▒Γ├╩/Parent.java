package 상속기초;

public class Parent {

	// 기존클래스, 부모클래스, 슈퍼클래스
	// 한식가게

	// 1. 제육볶음을 파는 메소드
	public void makejae() {
		System.out.println("맛있는 제육볶음을 만든다~~~");
	}

	// 2. 김치찌개를 파는 메소드
	public void makekimchi() {
		System.out.println("맛있는 김치찌개를 끓인다~~~");
	}
}
