package 계산게임;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		PlusGame pg = new PlusGame();

		for (int i = 0; i < 5; i++) {
			pg.makeRandom();
			int count = 0;
			while (count < 3) {
				count++;
				System.out.print(pg.getQuizMsg());
				int input = sc.nextInt();
				System.out.println(pg.checkAnswer(input));

				if (pg.checkAnswer(input)) {
					break;
				}
			}
		}
	}
}
