package 닌텐도게임;

public class Mario extends GameChip {

	public void gameStart() {
		System.out.println("마리오 게임을 시작한다~");
	}

}
