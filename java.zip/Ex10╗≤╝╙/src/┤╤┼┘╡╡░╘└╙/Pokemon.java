package 닌텐도게임;

public class Pokemon extends GameChip {

	// 포켓몬 게임을 시작한다~
	public void gameStart() {
		System.out.println("포켓몬 게임을 시작한다~");
	}
}
