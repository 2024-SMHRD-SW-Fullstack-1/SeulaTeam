package 닌텐도게임;

public class zelda extends GameChip {
	
	public void gameStart() {
		System.out.println("젤다의 전설을 시작한다~");
	}
}
