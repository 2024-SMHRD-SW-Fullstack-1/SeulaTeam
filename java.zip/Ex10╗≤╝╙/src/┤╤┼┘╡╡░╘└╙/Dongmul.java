package 닌텐도게임;

public class Dongmul extends GameChip {

	@Override
	public void gameStart() {
		System.out.println("동물의 숲을 시작한다~");
	}

}
